package com.example.gait_data_acquisition_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

//************************ Main Display ************************/
// User Info
// TimeStamp_sec,linear_acc_x,linear_acc_y,linear_acc_z ,gyro_x,gyro_y,gyro_z,roll, pitch, yaw, sex (0:male, 1:female) 총 11개 data ( 1 timestamp + 9 sensor vals + 1 sex val )

public class MainActivity extends AppCompatActivity {


    // User info related  Ojbects
    TextView name_text, trial_text, gait_type_text;
    EditText name_edit, trial_edit, gait_type_edit;
    RadioButton male_btn, female_btn;
    RadioGroup radioGroup;
    String user_sex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        object_init();

    }

    // 버튼 클릭 시 , 2 번쨰 화면 실행
    public void onClick_savestart(View view){
        Intent intent_main = new Intent(getApplicationContext(), SensorActivity.class);

        String name = name_edit.getText().toString();
        int trial = Integer.parseInt(trial_edit.getText().toString());
        String gait_type = gait_type_edit.getText().toString();

        intent_main.putExtra("name", name); // String
        intent_main.putExtra("trial", Integer.toString(trial)); // int -> to String
        intent_main.putExtra("gait_type",gait_type) ; //string
        intent_main.putExtra("sex", user_sex) ; //string


        startActivity(intent_main);
    }

    public void object_init(){
        user_sex = "male";

        name_text = (TextView) findViewById(R.id.name_textview);
        trial_text = (TextView) findViewById(R.id.trial_textview);
        gait_type_text = (TextView) findViewById(R.id.gait_type_textview);

        name_edit = (EditText) findViewById(R.id.name_editview);
        trial_edit = (EditText) findViewById(R.id.trial_editview);
        gait_type_edit = (EditText) findViewById(R.id.gait_type_editview);

        // Radio button 설정 + 리스너 설정
        male_btn = (RadioButton) findViewById(R.id.radioButton_male);
        female_btn = (RadioButton) findViewById(R.id.radioButton_female);


        // Radio group 설정
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(radioGroupButtonChangeListener);
    }

    RadioGroup.OnCheckedChangeListener radioGroupButtonChangeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int i) {
            if( i == R.id.radioButton_male){
                user_sex = male_btn.getText().toString();
            }
            else if(i == R.id.radioButton_female){
                user_sex = female_btn.getText().toString();
            }
        }

    };
}