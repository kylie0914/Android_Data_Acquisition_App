package com.example.gait_data_acquisition_v1;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class SensorActivity extends AppCompatActivity {

    // User Info. to make filename
    String name, trial, gait_type, user_sex;
    // Objects init     -- for display
    TextView lin_acc_x_val_text, lin_acc_y_val_text, lin_acc_z_val_text;  // acc val
    TextView gyro_x_val_text, gyro_y_val_text, gyro_z_val_text; // gyro val
    TextView roll_val_text, pitch_val_text, yaw_val_text;   // AHRS val
    Button save_end_btn;

    TextView file_name_text;
    String file_name;
    OutputStreamWriter fout;


                // *********** Sensor Enable  *************//
    SensorManager sm;
    SensorEventListener userSensorListener;
    Sensor gyroSensor = null;
    Sensor linear_accSensor = null;  //    accSensor = null;
    Sensor AHRS_Rotation_sensor = null;

    /* 센서 값 저장 변수 */
    double[] AHRS_vals = new double[3]; // roll, pitch, yaw
    float[] gyro_vals = new float[3]; // x, y, z
    float[] linear_acc_vals = new float[3]; // linear acc x,y,z
    double rad_to_degree = 180 / Math.PI;
    static final float nano_sec_to_sec = 1.0f/1000000000.0f;

            // ******************** Timer Thread ************ //
    // Save Sensor data thread  ---- Timer thread
    private Timer Save_Data_Timer;
    private TimerTask Save_Data_Timer_Task;
    private final Handler handler_Save_Data_Timer= new Handler();

    // Save time display Thread (1Hz) Timer
    private TimerTask Save_Display_Timer_1hz_Task;
    private Timer Save_Display_Timer_1hz;          // Timer
    private final Handler handler_Save_Display_Timer= new Handler();

    long CpuTimeStamp=0;
    long timestamp_ns;
    long save_time;

    public void Sensor_Init(){
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        linear_accSensor = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION); // 선형 가속도 센서 (움직일때 acc)
        gyroSensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);    // Gyro sensor
        AHRS_Rotation_sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR); // AHRS 센서
        userSensorListener  = new UserSensorListner();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 화면에 보여질 내용물 view 설정
        setContentView(R.layout.sensor_activity);

        // 내/외부 저장소 Permission 확인
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.READ_EXTERNAL_STORAGE)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);   }}           //읽기 권한 요청

        CpuTimeStamp = System.nanoTime();

        object_init();
        make_save_file();
        Sensor_Init();
        Timer_thread_Init();


    }

    // ******************* Sensor Value updates (Listener)
    public class UserSensorListner implements SensorEventListener {
        boolean sensor_changed = false;

        @Override
        public void onSensorChanged(SensorEvent event){
            switch(event.sensor.getType()){

                case Sensor.TYPE_LINEAR_ACCELERATION:
                    sensor_changed=true;
                    linear_acc_vals = event.values;
                    break;

                case Sensor.TYPE_GYROSCOPE:
                    sensor_changed=true;
                    gyro_vals = event.values;

                    break;
                case Sensor.TYPE_ROTATION_VECTOR:
                    sensor_changed=true;
                    updateOrientation(event.values);  // update roll, ptich , yaw
                    break;
            }
            display_sensor_values();  // Text View 에 Display

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {  }
    }

    public void onClick_saveend(View view){
        finish();
    }


    private void updateOrientation(float[] rotationVector){

        float[] eventValues = rotationVector;
        float[] rotationMatrix = {1f, 0f, 0f,   0f, 1f, 0f,   0f, 0f, 1f};

        try {
            sm.getRotationMatrixFromVector(rotationMatrix, eventValues);
        } catch(Exception e) {
            // Galaxy Note 3 bug
            float[]  eventValuesFixed = {eventValues[0], eventValues[1], eventValues[2]};
            sm.getRotationMatrixFromVector(rotationMatrix, eventValuesFixed);
        }

        float[]  orientation = {0f, 0f, 0f};
        orientation = sm.getOrientation(rotationMatrix, orientation);
        orientation[0] = - orientation[0];
        orientation[1] = - orientation[1];

        AHRS_vals[0] = orientation[2] * rad_to_degree; //  roll
        AHRS_vals[1]= orientation[1] * rad_to_degree;   // pich
        AHRS_vals[2] = orientation[0] * rad_to_degree; //  yaw
    }


    public void display_sensor_values(){
        lin_acc_x_val_text.setText("              " + String.format("%10.6f",linear_acc_vals[0]) );
        lin_acc_y_val_text.setText("              "  + String.format("%10.6f",linear_acc_vals[1]) );
        lin_acc_z_val_text.setText("              " + String.format("%10.6f",linear_acc_vals[2]) );

        gyro_x_val_text.setText("              " + String.format("%10.6f",gyro_vals[0]) );
        gyro_y_val_text.setText("              "  + String.format("%10.6f",gyro_vals[1]) );
        gyro_z_val_text.setText("              " + String.format("%10.6f",gyro_vals[2]) );

        roll_val_text.setText("              " + String.format("%10.6f",AHRS_vals[0]) );
        pitch_val_text.setText("              "  + String.format("%10.6f",AHRS_vals[1]) );
        yaw_val_text.setText("              " + String.format("%10.6f",AHRS_vals[2]) );

    }

    public void onResume(){     // SENSOR_DELAY_FASTEST >> SENSOR_DELAY_GAME >>  SENSOR_DELAY_NORMAL >> SENSOR_DELAY_UI
        super.onResume();          // 센서에 대한 listener 등록
        sm.registerListener(userSensorListener, linear_accSensor, SensorManager.SENSOR_DELAY_FASTEST);   // acc sensing rate
        sm.registerListener(userSensorListener, gyroSensor, SensorManager.SENSOR_DELAY_FASTEST);   // gyro sensing rate
        sm.registerListener(userSensorListener, AHRS_Rotation_sensor, SensorManager.SENSOR_DELAY_FASTEST);   // gyro sensing rate
    }

    public void onPause(){
        super.onPause();
        sm.unregisterListener(userSensorListener); // 액티비티 멈추면 센서 등록 해제
    }

    public void make_save_file(){
        Intent intent_sub = getIntent();

        name = intent_sub.getExtras().getString("name");
        trial = intent_sub.getExtras().getString("trial");
        gait_type = intent_sub.getExtras().getString("gait_type");
        user_sex = intent_sub.getExtras().getString("sex");

        long now = System.currentTimeMillis();  // 화면 켜질 떄의 시간 으로 파일명 생성
        Date mDate = new Date(now);
        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
        String getTime = simpleDate.format(mDate);


//        file_name = name  + "_" + gait_type + "_" + trial  + "_" + getTime +".csv" ;
        file_name = user_sex  + "_" + name +"_ " + gait_type + "_" + trial  + "_" + getTime +".csv" ;
        file_name_text.setText("     file name :"+  file_name.trim());

        // Permission Check
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            finish();
        }

        boolean sdCard_enable = false;
        boolean sdCard_writeable = false;
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            sdCard_enable = true;
            sdCard_writeable = false;
        } else
            sdCard_enable = sdCard_writeable = false;

        Log.i("[sdCard Status]","[Enable , Writeable]:" + sdCard_enable + sdCard_writeable);

        try {
            if (sdCard_enable) {
                File path = Environment.getExternalStoragePublicDirectory("Pathological_Data");
                Log.i("[File path]","Extneral File Path:  "+ path);
                path.mkdirs();
                File file_external = new File(path.getAbsolutePath(), file_name);
                fout =	new OutputStreamWriter(	new FileOutputStream(file_external));
            } else {
                fout=	new OutputStreamWriter(	openFileOutput(file_name, Context.MODE_PRIVATE));
                Log.i("[Internal]","Internal    Internal    Internal    Internal    Internal    Internal    ");
            }
            String Sensor_data = String.format(Locale.KOREA,"TimeStamp_sec,Acc_x,Acc_y,Acc_z,Gyro_x,Gyro_y,Gyro_z,Roll,Pich,Yaw,Sex\n");
            fout.write(Sensor_data);

         } catch (Exception ex) {
            Log.e("[File Error]", "Can't not make files");
        }

    }


                // ************************ Timer Init / Destroy / Classes ( Save data, Save time display) ****************************//
    // Timer Thread 생성
    public void Timer_thread_Init(){
        // Save_end_Btn 에 기록 시간 Display  -- 1 sec
        Save_display_Timer_thread();
        Save_Display_Timer_1hz = new Timer("Save Time Display Timer 1hz");
        Save_Display_Timer_1hz.scheduleAtFixedRate(Save_Display_Timer_1hz_Task, 1, 1000);

        // Sensor Save Timer setting  --------------------- 100hz = 10, 200hz = 5
        Save_Sensor_Data_thread();
        Save_Data_Timer = new Timer("Save Data Timer ");
        Save_Data_Timer.scheduleAtFixedRate(Save_Data_Timer_Task, 1, 5 ); //

    }

    // Timer Thread  소멸
    protected void onDestroy(){
        super.onDestroy();
        Log.i("Destroy", "============================= destroy -----------------------");
        try {
        Save_Display_Timer_1hz.cancel();
        Save_Data_Timer.cancel();
        fout.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //  Save time display Thread ( 1hz)
    private void Save_display_Timer_thread() {
        Save_Display_Timer_1hz_Task = new TimerTask() {
            public void run() {
                handler_Save_Display_Timer.post(new Runnable() {
                    public void run() {   // For Display
                            long timestamp_nano= System.nanoTime(); // in nano sec
                            if (timestamp_nano>=CpuTimeStamp)   {
                                timestamp_ns = timestamp_nano - CpuTimeStamp;
                            } else {
                                timestamp_ns = (timestamp_nano - CpuTimeStamp) + Long.MAX_VALUE;
                            }
                            save_time = (long)(((double)(timestamp_ns))*1E-9);
                            save_end_btn.setText("Stop Saving.\n "+Long.toString(save_time)+" s");
                    }
                } );
            }
        };
    }


    // Sensor data -- save thread ( 1 khz)
    private void Save_Sensor_Data_thread() {
        Save_Data_Timer_Task = new TimerTask() {
            public void run() {

                handler_Save_Data_Timer.post(new Runnable() {

                    public void run(){
                        try {
                            long timestamp_nano = System.nanoTime();//CpuTimeStamp;  // Current Nano time - 첫 화면  nano 타임 = (0초)
                            double TimeStamp_sec = (timestamp_nano - CpuTimeStamp) * nano_sec_to_sec; // ns->s 변환
                            Log.i("[Timestamp]", Double.toString(TimeStamp_sec));


                            if (user_sex.equalsIgnoreCase("male")){
                                String Sensor_data=String.format(Locale.KOREA,"%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%d\n",
                                        TimeStamp_sec,linear_acc_vals[0],linear_acc_vals[1],linear_acc_vals[2],gyro_vals[0],gyro_vals[1],gyro_vals[2],AHRS_vals[0],AHRS_vals[1],AHRS_vals[2], 0);
                                Log.i("[Save Data]", Sensor_data);
                                fout.write(Sensor_data);
                            }
                            if (user_sex.equalsIgnoreCase("female")) {
                                String Sensor_data=String.format(Locale.KOREA,"%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%5.6f,%d\n",
                                        TimeStamp_sec,linear_acc_vals[0],linear_acc_vals[1],linear_acc_vals[2],gyro_vals[0],gyro_vals[1],gyro_vals[2],AHRS_vals[0],AHRS_vals[1],AHRS_vals[2], 1);
                                Log.i("[Save Data]", Sensor_data);
                                fout.write(Sensor_data);

                            }

                        } catch (IOException e) {
                            Log.e("[Save Error]", "Can't not Save data ");
                            e.printStackTrace();
                        }

                    }
                } );
            }
        };
    }
    public void object_init(){
        save_end_btn = (Button) findViewById(R.id.save_end_button);
        file_name_text = (TextView) findViewById(R.id.file_name_textview);

        lin_acc_x_val_text = (TextView) findViewById(R.id.lin_acc_x_val_textview);
        lin_acc_y_val_text = (TextView) findViewById(R.id.lin_acc_y_val_textview);
        lin_acc_z_val_text = (TextView) findViewById(R.id.lin_acc_z_val_textview);

        gyro_x_val_text = (TextView) findViewById(R.id.gyro_x_val_textview);
        gyro_y_val_text = (TextView) findViewById(R.id.gyro_y_val_textview);
        gyro_z_val_text= (TextView) findViewById(R.id.gyro_z_val_textview);

        roll_val_text = (TextView) findViewById(R.id.roll_val_textview);
        pitch_val_text = (TextView) findViewById(R.id.pitch_val_textview);
        yaw_val_text = (TextView) findViewById(R.id.yaw_val_textview);
    }

}
